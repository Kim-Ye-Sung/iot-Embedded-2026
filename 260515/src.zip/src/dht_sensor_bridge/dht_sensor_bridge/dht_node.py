import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import serial

class DHTNode(Node):
    def __init__(self):
        super().__init__('dht_node')
        
        self.temp_pub = self.create_publisher(Float32, 'temperature', 10)
        self.humi_pub = self.create_publisher(Float32, 'humidity', 10)
        
        self.ser = serial.Serial('/dev/ttyACM0', 115200, timeout = 1)
        
        self.timer = self.create_timer(1.0, self.read_sensor)
        
    def read_sensor(self):
        line = self.ser.readline().decode().strip()
        
        try:
            temp_str, humi_str = line.split(',');
            temp = float(temp_str)
            humi = float(humi_str)
            
            temp_msg = Float32()
            humi_msg = Float32()
            
            temp_msg.data = temp
            humi_msg.data = humi
            
            self.temp_pub.publish(temp_msg)
            self.humi_pub.publish(humi_msg)
            
            self.get_logger().info(f'Temp: {temp} C, Humidity: {humi} %')
            
        except Exception:
            pass

def main(args = None):
    rclpy.init(args=args)
    node = DHTNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

