import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String


class TemperatureConditionNode(Node):
    def __init__(self):
        super().__init__('temperature_condition_node')

        self.open_temperature = 28.0
        self.close_temperature = 27.5

        self.subscriber = self.create_subscription(
            Float32,
            'dht_temperature',
            self.temperature_callback,
            10
        )

        self.publisher = self.create_publisher(
            String,
            'temperature_condition',
            10
        )

    def temperature_callback(self, msg):
        temperature = msg.data

        if temperature >= self.open_temperature:
            condition = 'OPEN'

        elif temperature < self.close_temperature:
            condition = 'CLOSE_READY'

        else:
            condition = 'HOLD'

        self.publish_condition(condition)

        self.get_logger().info(
            f'Temperature: {temperature:.2f} C -> {condition}'
        )

    def publish_condition(self, condition):
        msg = String()
        msg.data = condition
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = TemperatureConditionNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()