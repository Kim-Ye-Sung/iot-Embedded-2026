import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String


class UltrasonicConditionNode(Node):
    def __init__(self):
        super().__init__('ultrasonic_condition_node')

        self.open_distance = 30.0
        self.close_distance = 35.0

        self.subscriber = self.create_subscription(
            Float32,
            'ultrasonic_distance',
            self.distance_callback,
            10
        )

        self.publisher = self.create_publisher(
            String,
            'ultrasonic_condition',
            10
        )

    def distance_callback(self, msg):
        distance = msg.data

        if distance <= self.open_distance:
            condition = 'OPEN'

        elif distance >= self.close_distance:
            condition = 'CLOSE_READY'

        else:
            condition = 'HOLD'

        self.publish_condition(condition)

        self.get_logger().info(
            f'Distance: {distance:.2f} cm -> {condition}'
        )

    def publish_condition(self, condition):
        msg = String()
        msg.data = condition
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = UltrasonicConditionNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()