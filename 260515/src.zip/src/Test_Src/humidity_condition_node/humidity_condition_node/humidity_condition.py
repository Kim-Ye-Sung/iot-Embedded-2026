import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String


class HumidityConditionNode(Node):
    def __init__(self):
        super().__init__('humidity_condition_node')

        self.open_humidity = 70.0
        self.close_humidity = 65.0

        self.subscriber = self.create_subscription(
            Float32,
            'dht_humidity',
            self.humidity_callback,
            10
        )

        self.publisher = self.create_publisher(
            String,
            'humidity_condition',
            10
        )

    def humidity_callback(self, msg):
        humidity = msg.data

        if humidity >= self.open_humidity:
            condition = 'OPEN'

        elif humidity < self.close_humidity:
            condition = 'CLOSE_READY'

        else:
            condition = 'HOLD'

        self.publish_condition(condition)

        self.get_logger().info(
            f'Humidity: {humidity:.2f} % -> {condition}'
        )

    def publish_condition(self, condition):
        msg = String()
        msg.data = condition
        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)

    node = HumidityConditionNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()