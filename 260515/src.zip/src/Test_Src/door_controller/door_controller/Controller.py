import rclpy
from rclpy.node import Node

from std_msgs.msg import String


class Controller(Node):
    def __init__(self):
        super().__init__('controller')

        self.motor_opened = False

        self.ultrasonic_condition = None
        self.temperature_condition = None
        self.humidity_condition = None

        self.ultrasonic_subscriber = self.create_subscription(
            String,
            'ultrasonic_condition',
            self.ultrasonic_callback,
            10
        )

        self.temperature_subscriber = self.create_subscription(
            String,
            'temperature_condition',
            self.temperature_callback,
            10
        )

        self.humidity_subscriber = self.create_subscription(
            String,
            'humidity_condition',
            self.humidity_callback,
            10
        )

        self.motor_cmd_publisher = self.create_publisher(
            String,
            'motor_cmd',
            10
        )

    def ultrasonic_callback(self, msg):
        self.ultrasonic_condition = msg.data
        self.get_logger().info(f'Ultrasonic condition: {self.ultrasonic_condition}')

        self.check_motor_condition()

    def temperature_callback(self, msg):
        self.temperature_condition = msg.data
        self.get_logger().info(f'Temperature condition: {self.temperature_condition}')

        self.check_motor_condition()

    def humidity_callback(self, msg):
        self.humidity_condition = msg.data
        self.get_logger().info(f'Humidity condition: {self.humidity_condition}')

        self.check_motor_condition()

    def check_motor_condition(self):
        # 세 조건이 한 번씩은 들어와야 판단 시작
        if self.ultrasonic_condition is None:
            return

        if self.temperature_condition is None:
            return

        if self.humidity_condition is None:
            return

        # 세 조건을 리스트로 묶음
        conditions = [
            self.ultrasonic_condition,
            self.temperature_condition,
            self.humidity_condition
        ]

        # 하나라도 OPEN이면 열기
        should_open = 'OPEN' in conditions

        # 세 개 모두 CLOSE_READY이면 닫기
        should_close = (
            self.ultrasonic_condition == 'CLOSE_READY' and
            self.temperature_condition == 'CLOSE_READY' and
            self.humidity_condition == 'CLOSE_READY'
        )

        if self.motor_opened == False and should_open:
            self.publish_motor_command('OPEN')
            self.motor_opened = True

        elif self.motor_opened == True and should_close:
            self.publish_motor_command('CLOSE')
            self.motor_opened = False

    def publish_motor_command(self, command):
        msg = String()
        msg.data = command

        self.motor_cmd_publisher.publish(msg)

        self.get_logger().info(f'Published motor command: {command}')


def main(args=None):
    rclpy.init(args=args)

    node = Controller()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()