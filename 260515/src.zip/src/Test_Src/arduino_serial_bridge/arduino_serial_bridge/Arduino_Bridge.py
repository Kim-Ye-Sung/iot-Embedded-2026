import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String

import serial
import time


class ArduinoSerialBridge(Node):
    def __init__(self):
        super().__init__('arduino_bridge')

        port = '/dev/ttyACM0'
        baudrate = 115200

        try:
            self.ser = serial.Serial(port, baudrate, timeout=0.1)
            time.sleep(2)

            self.get_logger().info(f'Serial connected: {port}')

        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            self.ser = None

        # 초음파 거리값을 발행하는 Publisher
        self.distance_publisher = self.create_publisher(
            Float32,
            'ultrasonic_distance',
            10
        )

        # DHT 온도값을 발행하는 Publisher
        self.temperature_publisher = self.create_publisher(
            Float32,
            'dht_temperature',
            10
        )

        # DHT 습도값을 발행하는 Publisher
        self.humidity_publisher = self.create_publisher(
            Float32,
            'dht_humidity',
            10
        )

        # 모터 명령을 받는 Subscriber
        self.motor_cmd_subscriber = self.create_subscription(
            String,
            'motor_cmd',
            self.motor_cmd_callback,
            10
        )

        # 0.05초마다 시리얼에서 들어온 데이터 확인
        self.timer = self.create_timer(0.05, self.read_serial_data)

    def read_serial_data(self):
        if self.ser is None:
            return

        try:
            if self.ser.in_waiting > 0:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()

                if line == '':
                    return

                # 아두이노에서 들어오는 예시:
                # DIST:25.30,TEMP:27.50,HUM:61.00
                data = self.parse_sensor_line(line)

                if data is None:
                    self.get_logger().warn(f'Invalid serial format: {line}')
                    return

                distance = data['DIST']
                temperature = data['TEMP']
                humidity = data['HUM']

                if distance >= 0:
                    distance_msg = Float32()
                    distance_msg.data = distance
                    self.distance_publisher.publish(distance_msg)

                    self.get_logger().info(f'Published distance: {distance:.2f} cm')
                else:
                    self.get_logger().warn('Invalid distance received')

                if temperature == temperature:
                    temperature_msg = Float32()
                    temperature_msg.data = temperature
                    self.temperature_publisher.publish(temperature_msg)

                    self.get_logger().info(f'Published temperature: {temperature:.2f} C')
                else:
                    self.get_logger().warn('Invalid temperature received')

                if humidity == humidity:
                    humidity_msg = Float32()
                    humidity_msg.data = humidity
                    self.humidity_publisher.publish(humidity_msg)

                    self.get_logger().info(f'Published humidity: {humidity:.2f} %')
                else:
                    self.get_logger().warn('Invalid humidity received')

        except Exception as e:
            self.get_logger().error(f'Serial read error: {e}')

    def parse_sensor_line(self, line):
        try:
            result = {}

            # line 예시:
            # DIST:25.30,TEMP:27.50,HUM:61.00
            parts = line.split(',')

            for part in parts:
                key, value = part.split(':')
                result[key] = float(value)

            if 'DIST' not in result:
                return None

            if 'TEMP' not in result:
                return None

            if 'HUM' not in result:
                return None

            return result

        except Exception:
            return None

    def motor_cmd_callback(self, msg):
        if self.ser is None:
            self.get_logger().error('Serial is not connected')
            return

        command = msg.data.strip().upper()

        if command not in ['OPEN', 'CLOSE']:
            self.get_logger().warn(f'Unknown motor command: {command}')
            return

        try:
            send_data = command + '\n'
            self.ser.write(send_data.encode('utf-8'))

            self.get_logger().info(f'Sent to Arduino: {command}')

        except Exception as e:
            self.get_logger().error(f'Serial write error: {e}')


def main(args=None):
    rclpy.init(args=args)

    node = ArduinoSerialBridge()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        if node.ser is not None:
            node.ser.close()

        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()