#include <DHT.h>

const int trigPin = 2;
const int echoPin = 3;

const int IN1 = 4;
const int IN2 = 5;
const int IN3 = 6;
const int IN4 = 7;

const int ledPin = 8;

const int dhtPin = 9;

#define DHTTYPE DHT11

DHT dht(dhtPin, DHTTYPE);

const int stepsFor90Degree = 1024;

// 스텝 간 대기 시간
const int stepDelay = 2;

// 센서 측정 주기
const unsigned long sensorInterval = 1000;
unsigned long lastSensorTime = 0;

// 모터가 현재 열려있는지 상태 저장
bool motorOpened = false;

const int stepSequence[8][4] = {
  {1, 0, 0, 0},
  {1, 1, 0, 0},
  {0, 1, 0, 0},
  {0, 1, 1, 0},
  {0, 0, 1, 0},
  {0, 0, 1, 1},
  {0, 0, 0, 1},
  {1, 0, 0, 1}
};

void setup()
{
  Serial.begin(115200);

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  pinMode(ledPin, OUTPUT);

  // DHT 센서 시작
  dht.begin();

  // 처음 시작할 때 모터 OFF
  motorOff();

  // 처음 시작할 때 LED OFF
  digitalWrite(ledPin, HIGH);
}

void loop()
{
  readSerialCommand();

  unsigned long currentTime = millis();

  if (currentTime - lastSensorTime >= sensorInterval)
  {
    lastSensorTime = currentTime;

    float distanceCm = getDistanceCm();
    float temperature = dht.readTemperature(); 
    float humidity = dht.readHumidity();       


    Serial.print("DIST:");
    Serial.print(distanceCm);

    Serial.print(",TEMP:");
    Serial.print(temperature);

    Serial.print(",HUM:");
    Serial.println(humidity);
  }
}

float getDistanceCm()
{
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0)
  {
    return -1.0;
  }

  float distanceCm = duration * 0.034 / 2.0;

  return distanceCm;
}

void readSerialCommand()
{
  if (Serial.available() > 0)
  {
    String command = Serial.readStringUntil('\n');
    command.trim();

    if (command == "OPEN")
    {
      if (motorOpened == false)
      {
        digitalWrite(ledPin, LOW);

        rotateStepper(stepsFor90Degree, true);

        motorOff();

        motorOpened = true;
      }
    }
    else if (command == "CLOSE")
    {
      if (motorOpened == true)
      {
        rotateStepper(stepsFor90Degree, false);

        motorOff();

        motorOpened = false;

        // 완전히 닫힌 뒤 LED OFF
        digitalWrite(ledPin, HIGH);
      }
    }
  }
}

void rotateStepper(int steps, bool direction)
{
  for (int i = 0; i < steps; i++)
  {
    int stepIndex;

    if (direction == true)
    {
      stepIndex = i % 8;
    }
    else
    {
      stepIndex = 7 - (i % 8);
    }

    setStep(stepIndex);
    delay(stepDelay);
  }
}

void setStep(int stepIndex)
{
  digitalWrite(IN1, stepSequence[stepIndex][0]);
  digitalWrite(IN2, stepSequence[stepIndex][1]);
  digitalWrite(IN3, stepSequence[stepIndex][2]);
  digitalWrite(IN4, stepSequence[stepIndex][3]);
}

void motorOff()
{
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}
