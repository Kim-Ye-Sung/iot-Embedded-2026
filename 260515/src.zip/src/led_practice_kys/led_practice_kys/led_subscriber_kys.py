import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
import time


class LedSerialSubscriber(Node):
    def __init__(self):
        super().__init__('led_serial_subscriber')

        # 아두이노가 연결된 시리얼 포트
        port = '/dev/ttyACM0'
        baudrate = 115200

        try:
            self.ser = serial.Serial(port, baudrate, timeout=1)
            time.sleep(2)  # 아두이노가 시리얼 연결 후 리셋되는 시간 대기
            self.get_logger().info(f'Serial connected: {port}')

        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            self.ser = None

        # /led_cmd 토픽 구독
        self.subscription = self.create_subscription(
            String,
            'led_cmd',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        if self.ser is None:
            self.get_logger().error('Serial not available')
            return

        # 사용자가 보낸 문자열을 소문자로 정리
        data = msg.data.strip().lower()

        if data == 'r':
            self.ser.write(b'R\n')
            self.get_logger().info('Sent: R')

        elif data == 'b':
            self.ser.write(b'B\n')
            self.get_logger().info('Sent: B')

        elif data == 'g':
            self.ser.write(b'G\n')
            self.get_logger().info('Sent: G')

        elif data == 'off':
            self.ser.write(b'OFF\n')
            self.get_logger().info('Sent: OFF')

        else:
            self.get_logger().warn(f'Unknown command: {msg.data}')


def main(args=None):
    rclpy.init(args=args)

    node = LedSerialSubscriber()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    if node.ser is not None:
        node.ser.close()

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
