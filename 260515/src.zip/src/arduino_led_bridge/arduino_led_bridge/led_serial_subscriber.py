import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial
import time

class LedSerialSubscriber(Node):
    def __init__(self):
        super().__init__('led_serial_subscriber')

        # 아두이노 포트 확인 후 수정
        port = '/dev/ttyACM0'
        baudrate = 115200

        try:
            self.ser = serial.Serial(port, baudrate, timeout=1)
            time.sleep(2)  # 아두이노 리셋 대기
            self.get_logger().info(f'Serial connected: {port}')
        except Exception as e:
            self.get_logger().error(f'Failed to open serial port: {e}')
            self.ser = None

        self.subscription = self.create_subscription(
            String,
            'led_cmd',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        if self.ser is None:
            self.get_logger().error('Serial not available')
            return

        data = msg.data.strip().lower()

        if data == 'on':
            self.ser.write(b'ON\n')
            self.get_logger().info('Sent: ON')
        elif data == 'off':
            self.ser.write(b'OFF\n')
            self.get_logger().info('Sent: OFF')
        else:
            self.get_logger().warn(f'Unknown command: {msg.data}')


def main(args=None):
    rclpy.init(args=args)
    node = LedSerialSubscriber()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    if node.ser is not None:
        node.ser.close()

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
